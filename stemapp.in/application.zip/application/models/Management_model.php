
<?php
date_default_timezone_set("Asia/Calcutta");
defined('BASEPATH') OR exit('No direct script access allowed');
require_once('Menu_model.php');
class Management_model  extends Menu_model {

    public function __construct() {
        parent::__construct();
        // Load database or other necessary operations
        $db2 = $this->load->database('db2', TRUE);
        $db3 = $this->load->database('db3', TRUE);
    }


    public function CheckingDayManage($uid,$cdate){

        $utype = $this->Menu_model->get_userbyid($uid);
        $utype = $utype[0]->type_id;
        if($utype ==15){
            $query=$this->db->query("SELECT user_details.user_id, user_details.name,user_day.* FROM `user_day` LEFT JOIN user_details on user_details.user_id = user_day.user_id WHERE user_details.sales_co = $uid and cast(sdatet as DATE)='$cdate'");
        }
        if($utype ==13){
            $query=$this->db->query("SELECT user_details.user_id, user_details.name,user_day.* FROM `user_day` LEFT JOIN user_details on user_details.user_id = user_day.user_id WHERE user_details.aadmin = $uid and cast(sdatet as DATE)='$cdate'");
        }
        

        return $query->result();
       
    }

    public function CheckingYesterDayTaskStatus($uid){
        $date = new DateTime();
        $date->modify('-1 day');
        $pdate =  $date->format('Y-m-d');
        $query=$this->db->query("SELECT COUNT(*) AS plan, COUNT(CASE WHEN autotask = 1 THEN autotask END) AS autotask, COUNT(CASE WHEN nextCFID != 0 THEN 1 END) AS done, COUNT(CASE WHEN nextCFID = 0 AND lastCFID = 0 THEN 1 END) AS pending FROM tblcallevents WHERE assignedto_id = $uid AND CAST(appointmentdatetime AS DATE) = '$pdate'");

        return $query->result();
       
    }

    public function CheckingTotalYestTask($uid,$sdate,$type){
        if($type == 'total'){
            $query=$this->db->query("SELECT * FROM `tblcallevents` WHERE assignedto_id = $uid and cast(appointmentdatetime as DATE)='$sdate'");
        }
        if($type == 'Pending'){
            $query=$this->db->query("SELECT * FROM `tblcallevents` WHERE nextCFID =0 AND assignedto_id = $uid and cast(appointmentdatetime as DATE)='$sdate'");
        }
        if($type == 'autotask'){
            $query=$this->db->query("SELECT * FROM `tblcallevents` WHERE autotask =1 AND assignedto_id = $uid and cast(appointmentdatetime as DATE)='$sdate'");
        }
        if($type == 'done'){
            $query=$this->db->query("SELECT * FROM `tblcallevents` WHERE nextCFID != 0 AND assignedto_id = $uid and cast(appointmentdatetime as DATE)='$sdate'");
        }
        // echo $str = $this->db->last_query(); 
        return $query->result();
    }


    public function CheckAutoTaskTime($uid,$date) {
        $query=$this->db->query("SELECT * FROM `autotask_time` WHERE user_id = $uid AND date = '$date'");
        return $query->result();
    }

    public function CheckTaskPlanRequest($uid,$date) {
        $query=$this->db->query("SELECT * FROM `task_plan_for_today` WHERE user_id =$uid AND date ='$date'");
        return $query->result();
    }

    public function CheckingYesterDayConsumeTime($uid,$date) {
        $query=$this->db->query("SELECT * FROM `user_day` WHERE user_id = $uid and cast(sdatet as DATE)='$date'");
        return $query->result();
    }

    public function CheckStarRatingsExistorNot($uid,$date) {
        $query=$this->db->query("SELECT * FROM `star_rating` WHERE user_id = $uid AND date ='$date'");
        return $query->result();
    }


    public function CheckEveningStarRatingsExistorNot($uid,$date) {
        $query=$this->db->query("SELECT * FROM `star_rating` WHERE user_id = $uid AND (date ='$date' AND periods='Yesterday Evening')");
        return $query->result();
    }

    public function CheckYestTaskStarRatingsExistorNot($uid,$date) {
        $query=$this->db->query("SELECT * FROM `star_rating` WHERE user_id = $uid AND (date ='$date' AND periods='Yesterday Task')");
        return $query->result();
        // echo $str = $this->db->last_query(); 
    }


    public function getStarRatingRemarks($uid,$date) {
        $query=$this->db->query("SELECT * FROM `star_rating` WHERE user_id = $uid AND date ='$date'");
        return $query->result();
    }

    public function AddStarRating($sdate,$suser_id,$periods,$question,$star,$remarks,$feedback_by){
        $data = [
            'date' => $sdate,
            'user_id' => $suser_id,
            'periods' => $periods,
            'question' => $question,
            'star'=>$star,
            'remarks'=>$remarks,
            'feedback_by'=>$feedback_by,
        ];
        $this->db->insert('star_rating',$data);
    }



}
