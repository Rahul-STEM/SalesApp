<?php
date_default_timezone_set("Asia/Calcutta");
defined('BASEPATH') OR exit('No direct script access allowed');
require_once('Menu.php');
class Management extends Menu {

    private $user;
    private $uid;
    private $uyid;
    private $dep_name;
    private $dt;

    public function __construct() {
        parent::__construct();
        // Load common libraries, helpers, or models here
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->model('Menu_model');
        $this->load->model('Management_model');

        $this->user = $this->session->userdata('user');
        $this->uid = $this->user['user_id'];
        $this->uyid =  $this->user['type_id'];

        $this->dt = $this->Menu_model->get_utype($this->uyid);

        $this->dep_name = $this->dt[0]->name;
        if ($this->uyid != 15 && $this->uyid != 13) {
            echo "Stem Learning Pvt Ltd";
            echo "<br/>";
            exit;
        }

    }

    public function Manage() {

        if(!empty($this->user)){
            $this->load->view($this->dep_name.'/Manage',['uid'=>$this->uid,'user'=>$this->user]);
        }else{
            redirect('Menu/main');
        }
    }

    public function CheckingDayManagement(){

        $cdate = date("Y-m-d");
        $sdate = new DateTime($cdate);
        $sdate->modify('-1 day');
        $previousDate = $sdate->format('Y-m-d');

        $dayData = $this->Management_model->CheckingDayManage($this->uid,$cdate);
        
        if(!empty($this->user)){
            $this->load->view($this->dep_name.'/CheckingDayManagement',['uid'=>$this->uid,'user'=>$this->user,'dayData'=>$dayData,'cdate'=>$cdate,'previousDate'=>$previousDate]);
        }else{
            redirect('Menu/main');
        }
    }
  
    public function CheckingYesterDayTask($type,$userid,$sdate){
        
        $sdate = new DateTime($sdate);
        $sdate->modify('-1 day');
        $previousDate = $sdate->format('Y-m-d');

        $dayData = $this->Management_model->CheckingTotalYestTask($userid,$previousDate,$type);
        
       $cdate = date("Y-m-d");
        if(!empty($this->user)){
            $this->load->view($this->dep_name.'/CheckingYesterTask',['uid'=>$this->uid,'user'=>$this->user,'dayData'=>$dayData,'cdate'=>$cdate,'previousDate'=>$previousDate]);
        }else{
            redirect('Menu/main');
        }
    }


    public function checkdayswithStar(){
        $periods = $_POST['periods'];
        $suser_id = $_POST['udid'];
        $cdate = $_POST['cdate'];
        $previousDate = $_POST['previousDate'];

        $rat1 = $_POST['rat1'];
        $rat2 = $_POST['rat2'];
        $rat3 = $_POST['rat3'];
        $rat4 = $_POST['rat4'];
       
        $que = $_POST['que'];
        $remarks = $_POST['sremark'];
        
        if($periods == 'Mornings'){
            $rat5 = $_POST['rat5'];
            $rat6 = $_POST['rat6'];
            $star = [$rat1,$rat2,$rat3,$rat4,$rat5,$rat6];
            $i=0;
            foreach($que as $q){
                $this->Management_model->AddStarRating($cdate,$suser_id,$periods,$q,$star[$i],$remarks,$this->uid);
                $i++;
            }
        }

        if($periods == 'Yesterday Evening' || $periods == 'Yesterday Task'){
            $star = [$rat1,$rat2,$rat3,$rat4];
            $i=0;
            foreach($que as $q){
                $this->Management_model->AddStarRating($previousDate,$suser_id,$periods,$q,$star[$i],$remarks,$this->uid);
                $i++;
            }
        }

        $this->session->set_flashdata('success_message', 'Star Rating Added Successfully');
        redirect('Management/CheckingDayManagement');
    }




}
