<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied</title>
    <style>
        body{
background-color: #100;
color: white;
}

h1 {
color: red;
}

h6{
color: red;
  font-weight: 100;
text-decoration: none; /*underline;*/
}


    </style>
</head>
<body>
    
<div class="w3-display-middle">
  <h1 class="w3-jumbo w3-animate-top w3-center"><code>Access Denied</code></h1>
  <hr class="w3-border-white w3-animate-left" style="margin:auto;width:50%">
  <h3 class="w3-center w3-animate-right">You dont have permission to view this site.</h3>
  <h3 class="w3-center w3-animate-zoom">🚫🚫🚫🚫</h3>
  <h6 class="w3-center w3-animate-zoom"><strong>Error Code</strong>: 403 forbidden</h6>
</div>
</body>
</html>